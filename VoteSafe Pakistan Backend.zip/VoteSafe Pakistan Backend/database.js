const { createPool } = require('mysql');

// Create a connection pool
const pool = createPool({
    host: "localhost",
    user: "root",
    password: "",
    database: "e_voting",
    connectionLimit: 10
});

// Example query to check the connection (this can be removed later)
pool.query(`select * from users`, (err, result, fields) => {
    if (err) {
        return console.log(err);
    }
    return console.log(result);
});

// Export the pool to use it in other files (like in the routes)
module.exports = pool;
