const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const bcrypt = require('bcrypt');
const session = require('express-session');
const pool = require('./database'); // Import the connection pool

const app = express();
const port = 5000;

// Middleware
app.use(bodyParser.json());
app.use(cors());
app.use(express.urlencoded({ extended: true }));
app.use(express.static('public')); // Serve static files from 'public' directory

app.use(session({
    secret: 'your_secret_key',
    resave: false,
    saveUninitialized: true
}));

// Middleware to check if user is authenticated
function checkAuth(req, res, next) {
    if (req.session && req.session.userId) {
        next();
    } else {
        res.redirect('/login');
    }
}

// Default Route (redirect to home)
app.get('/', (req, res) => {
    res.redirect('/home');
});

// Home route
app.get('/home', (req, res) => {
    res.sendFile(__dirname + '/public/home.html');
});

// Login Options route (GET)
app.get('/login-options', (req, res) => {
    res.sendFile(__dirname + '/public/login-options.html');
});

// Registration route (GET)
app.get('/register', (req, res) => {
    res.sendFile(__dirname + '/public/register.html');
});

// Registration route (POST)
app.post('/register', (req, res) => {
    const { firstname, lastname, cnic, email, password } = req.body;

    // Check if CNIC already exists
    const checkCnicSql = 'SELECT * FROM users WHERE cnic = ?';
    pool.query(checkCnicSql, [cnic], (err, results) => {
        if (err) throw err;

        if (results.length > 0) {
            // CNIC already exists
            res.send(`
                <h1>Registration Failed</h1>
                <p>CNIC already exists. Please use a different CNIC.</p>
                <a href="/register">Retry Registration</a>
            `);
        } else {
            // Hash the password
            bcrypt.hash(password, 10, (err, hash) => {
                if (err) throw err;

                // Insert user into the database
                const sql = 'INSERT INTO users (firstname, lastname, cnic, email, password_hash) VALUES (?, ?, ?, ?, ?)';
                pool.query(sql, [firstname, lastname, cnic, email, hash], (error, results) => {
                    if (error) throw error;
                    // Redirect to success page
                    res.redirect(`/registration-success?firstname=${firstname}&lastname=${lastname}&cnic=${cnic}`);
                });
            });
        }
    });
});

// Registration Success route (GET)
app.get('/registration-success', (req, res) => {
    res.sendFile(__dirname + '/public/registration-success.html');
});


// Login route (GET)
app.get('/login', (req, res) => {
    res.sendFile(__dirname + '/public/login.html');
});

// Login route (POST)
app.post('/login', (req, res) => {
    const { email, password } = req.body;

    // Query the database for the user
    const sql = 'SELECT * FROM users WHERE email = ?';
    pool.query(sql, [email], (error, results) => {
        if (error) throw error;

        if (results.length > 0) {
            const user = results[0];

            // Compare the password with the hashed password
            bcrypt.compare(password, user.password_hash, (err, match) => {
                if (err) throw err;

                if (match) {
                    req.session.userId = user.user_id; // Setting user session
                    req.session.firstname = user.firstname; // Store first name in session
                    res.redirect('/user');
                } else {
                    res.send(`
                        <h1>Login Failed</h1>
                        <p>Invalid credentials. Please try again.</p>
                        <a href="/login">Retry Login</a>
                    `);
                }
            });
        } else {
            res.send(`
                <h1>Login Failed</h1>
                <p>Invalid credentials. Please try again.</p>
                <a href="/login">Retry Login</a>
            `);
        }
    });
});

// User dashboard route (GET)
app.get('/user', checkAuth, (req, res) => {
  const firstname = req.session.firstname; // Get first name from session
  res.send(`
      <!DOCTYPE html>
      <html lang="en">
      <head>
          <meta charset="UTF-8">
          <meta name="viewport" content="width=device-width, initial-scale=1.0">
          <title>User Dashboard</title>
          <style>
              body {
                  background-color: #f4f4f4;
                  font-family: Arial, sans-serif;
                  padding: 50px;
              }
              h1 {
                  text-align: center;
                  font-size: 40px;
                  color: #333;
              }
              .button-container {
                  text-align: center;
                  margin-top: 30px;
              }
              .button-container a {
                  display: inline-block;
                  padding: 15px 30px;
                  margin: 10px;
                  background-color: #4CAF50;
                  color: white;
                  text-decoration: none;
                  font-size: 20px;
                  border-radius: 5px;
              }
              .button-container a:hover {
                  background-color: #45a049;
              }
          </style>
      </head>
      <body>
          <h1>Welcome to Your Dashboard, ${firstname}</h1>
          <div class="button-container">
              <a href="/elections">Elections</a>
              <a href="/personal-info">Personal Info</a>
              <a href="#">Vote</a>
              <a href="/logout">Logout</a>
          </div>
      </body>
      </html>
  `);
});

// Elections route (GET)
app.get('/elections', checkAuth, (req, res) => {
    const sql = 'SELECT * FROM election';
    pool.query(sql, (error, results) => {
        if (error) throw error;

        let electionsHtml = '<h1>Elections Information</h1><table border="1"><tr><th>ID</th><th>Type</th><th>Start Date</th><th>End Date</th><th>Region ID</th><th>Status</th></tr>';
        results.forEach(election => {
            electionsHtml += `<tr><td>${election.election_id}</td><td>${election.type}</td><td>${election.start_date}</td><td>${election.end_date}</td><td>${election.region_id}</td><td>${election.status}</td></tr>`;
        });
        electionsHtml += '</table><a href="/user">Go back</a>';

        res.send(`
            <!DOCTYPE html>
            <html lang="en">
            <head>
                <meta charset="UTF-8">
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <title>Elections</title>
                <style>
                    body {
                        background-color: #f4f4f4;
                        font-family: Arial, sans-serif;
                        padding: 50px;
                    }
                    table {
                        width: 100%;
                        border-collapse: collapse;
                        margin-bottom: 20px;
                    }
                    table, th, td {
                        border: 1px solid #333;
                    }
                    th, td {
                        padding: 10px;
                        text-align: left;
                    }
                    a {
                        display: inline-block;
                        padding: 10px 20px;
                        background-color: #4CAF50;
                        color: white;
                        text-decoration: none;
                        border-radius: 5px;
                    }
                    a:hover {
                        background-color: #45a049;
                    }
                </style>
            </head>
            <body>
                ${electionsHtml}
            </body>
            </html>
        `);
    });
});

// Personal Info route (GET)
app.get('/personal-info', checkAuth, (req, res) => {
  const userId = req.session.userId;

  const sql = 'SELECT * FROM users WHERE user_id = ?';
  pool.query(sql, [userId], (error, results) => {
      if (error) throw error;

      const user = results[0];
      const userHtml = `
          <h1>Personal Information</h1>
          <p>First Name: ${user.firstname}</p>
          <p>Last Name: ${user.lastname}</p>
          <p>CNIC: ${user.cnic}</p>
          <p>Email: ${user.email}</p>
          <p>Status: ${user.status}</p>
          <a href="/user">Go back</a>
      `;

      res.send(`
          <!DOCTYPE html>
          <html lang="en">
          <head>
              <meta charset="UTF-8">
              <meta name="viewport" content="width=device-width, initial-scale=1.0">
              <title>Personal Info</title>
              <style>
                  body {
                      background-color: #f4f4f4;
                      font-family: Arial, sans-serif;
                      padding: 50px;
                  }
                  a {
                      display: inline-block;
                      padding: 10px 20px;
                      background-color: #4CAF50;
                      color: white;
                      text-decoration: none;
                      border-radius: 5px;
                  }
                  a:hover {
                      background-color: #45a049;
                  }
              </style>
          </head>
          <body>
              ${userHtml}
          </body>
          </html>
      `);
  });
});

// Logout route
app.get('/logout', (req, res) => {
    req.session.destroy((err) => {
        if (err) {
            return console.log(err);
        }
        res.redirect('/login');
    });
});

// Additional routes (optional)
app.get('/about', (req, res) => {
    res.send('<h1>About VoteSafe</h1><p>Welcome to the About page!</p>');
});

app.get('/contact', (req, res) => {
    res.send('<h1>Contact VoteSafe</h1><p>Contact us at: contact@votesafe.com</p>');
});

app.get('/blockchain-explorer', (req, res) => {
    res.send('<h1>Blockchain Explorer</h1><p>Explore the blockchain data here!</p>');
});

// Start the server
app.listen(port, () => {
    console.log(`Server running on http://localhost:${port}`);
});










